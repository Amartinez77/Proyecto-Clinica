<?php
class DB extends DBmysql {
   public $dbhost = 'mysql:3306';
   public $dbuser = 'app_user';
   public $dbpassword = 'userpassword';
   public $dbdefault = 'glpi';
   public $use_timezones = true;
   public $use_utf8mb4 = true;
   public $allow_datetime = false;
   public $allow_signed_keys = false;
}
